using System.Collections.Generic;

public class Supplier
{
    public int SupplierId { get; set; }
    public string Name { get; set; }

    public List<Product> Products { get; set; }
}
